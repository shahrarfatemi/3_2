//Done!
public interface Constants {

    final int INFINITY = 30;
    final double LAMBDA = 0.10;

}